<?php
include "studentnav.php";
include "link.php";
include "db_connect.php";
?>

<?php
if (isset($_GET['Delete'])) {
  $id = $_GET['Delete'];
  $sql = "DELETE FROM `users` WHERE `id` = $id";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
     Deleted Successfully!
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>';
  }
}
if (isset($_POST['snoEdit'])) {
  $editno = $_POST['snoEdit'];
  $editname = $_POST['teacher_name_edit'];
  $editdep = $_POST['department_edit'];
  $sql = "UPDATE `users` SET `name` = '$editname' , `department` = '$editdep' WHERE `users`.`id` = $editno";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
       Updated successfully!
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>';
  } else {
    echo "not updated";
  }
} else {
  if (isset($_POST['submit'])) {
    $teacher_name = $_POST['teacher_name'];
    $teacher_dep = $_POST['department'];
    $sql = "INSERT INTO `teachers` (teacher_name,  teacher_department) VALUES (' $teacher_name', ' $teacher_dep')";
    $insert = mysqli_query($conn, $sql);
    if ($insert) {
      echo '<div class="alert alert-primary alert-dismissible fade show" role="alert">
         Added!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    } else {
      echo "not";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="//cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
</head>

<body>

  <!-- Button trigger modal -->
  <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button> -->

  <!-- Modal -->
  <div class="modal fade" id="EditModal" tabindex="-1" role="dialog" aria-labelledby="EditModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="EditModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="show_teachers_dep.php" method="POST">
            <div class="form-group">
              <label for="exampleInputEmail1">Name</label>
              <input type="text" name="t_nameedit" class="form-control" id="t_nameedit" aria-describedby="emailHelp" required>
            </div>

            <div class="form-group">
              <label for="exampleInputPassword1">Username</label>
              <input type="text" name="t_usernameedit" class="form-control" id="t_usernameedit" Required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Email Address</label>
              <input type="email" name="t_emailedit" class="form-control" id="t_emailedit" Required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Department</label>
              <input type="text" name="t_departmentedit" class="form-control" id="t_departmentedit" Required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Password</label>
              <input type="password" name="t_passwordedit" class="form-control" id="t_passwordedit" Required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Confirm Password</label>
              <input type="password" name="t_cpasswordedit" class="form-control" id="t_cpasswordedit" Required>
            </div>
            <div class="form-group">
              <div class="row">
                <!-- <div class="col-lg-6 mt-5">
                  <button name="submit" class="btn  active  " role="button" aria-pressed="true" style="color:rgb(43, 39, 145); background-color:rgb(134, 198, 247);  ">Add details</button>
                </div> -->
                <!-- <div class="col-lg-6 mt-5">
                  <a href="show_teachers_dep.php" class="btn  active  " role="button" aria-pressed="true" style="color:rgb(43, 39, 145); background-color:rgb(134, 198, 247);  ">Check details</a>
                </div> -->

              </div>

            </div>

          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <table class="table" id="myTable">
      <thead>
        <tr>
          <th scope="col">Sno</th>
          <th scope="col">Teacher Name</th>
          <th scope="col">teacher Department</th>
          <th scope="col">teacher Email</th>
          <th scope="col"><a href="Add_courses.php" class="btn">View Courses</a></th>

        </tr>
      </thead>
      <?php
      $role_id = 2;
      $sql = "SELECT * FROM users WHERE role_id = '{$role_id}'";
      $result = mysqli_query($conn, $sql);
      while ($row = mysqli_fetch_assoc($result)) {
        // echo $row['id'];
        // echo $row['courses_heading'];

        $id = $row['id'];
        $name = $row['name'];
        $department = $row['department'];
        $email = $row['email'];
        echo '<div class="container">
  <tr>
    <th scope="row">' . $id . '</th>
    <td>' . $name . '</td>
    <td>' . $department . '</td>
    <td>' . $email . '</td>
    <td><button class="Edit btn bg-white" data-toggle="modal" data-target="#EditModal" id=' . $row['id'] . '>Edit</button></td>
    <td><button class="Delete btn bg-white"  id=' . $row['id'] . ' name="delete">Delete</button></td>
    
  </tr>
</div>
';
      }

      ?>
    </table>
  </div>
  <script src="//cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
  <script>
    $(document).ready(function() {
      $('#myTable').DataTable();
    });
  </script>
  <script>
    edits = document.getElementsByClassName('Edit');
    Array.from(edits).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("Edit");
        tr = e.target.parentNode.parentNode;
        name = tr.getElementsByTagName("td")[0].innerText;
        department = tr.getElementsByTagName("td")[1].innerText;
        console.log(name, department);
        teacher_name_edit.value = name;
        department_edit.value = department;
        snoEdit.value = e.target.id;
        console.log(e.target.id);
        $('#EditModal').modal('toggle');
      })
    })

    deletes = document.getElementsByClassName('Delete');
    Array.from(deletes).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("Delete");
        id = e.target.id.substr(0);
        if (confirm("Are you sure you want to delete this??")) {
          console.log("yes");
          window.location = `show_teachers_dep.php?Delete=${id}`;
        } else {
          console.log("no");
        }

      })
    })
  </script>
</body>

</html>